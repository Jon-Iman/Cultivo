import { useState } from "react";
import Calendar from "react-calendar";
import { addDays, format, isSameDay } from "date-fns";
import "react-calendar/dist/Calendar.css";
import "./index.css";
import { useTranslation } from 'react-i18next';
import './i18n';

function App() {
  const { t, i18n } = useTranslation();
  const [cultivos, setCultivos] = useState([]);
  const [nombreCultivo, setNombreCultivo] = useState("");
  const [fechaSiembra, setFechaSiembra] = useState("");
  const [frecuenciaRiego, setFrecuenciaRiego] = useState(3);

  const agregarCultivo = () => {
    if (!nombreCultivo || !fechaSiembra || !frecuenciaRiego) return;
    setCultivos([...cultivos, { id: Date.now(), nombre: nombreCultivo, fecha: new Date(fechaSiembra), frecuencia: parseInt(frecuenciaRiego) }]);
    setNombreCultivo(""); setFechaSiembra(""); setFrecuenciaRiego(3);
  };

  const obtenerDiasRiego = () => cultivos.flatMap(c =>
    Array.from({ length: 20 }).map((_, i) => ({ fecha: addDays(c.fecha, i * c.frecuencia), nombre: c.nombre }))
  );

  const diasRiego = obtenerDiasRiego();

  return (
    <div className="min-h-screen bg-cover bg-center bg-no-repeat flex flex-col items-center justify-start pt-10 px-4"
         style={{ backgroundImage: "url('https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=1350&q=80')" }}>
      <div className="absolute top-4 left-4 z-10">
        <div className="text-2xl font-bold text-white bg-green-700 w-12 h-12 rounded-full flex items-center justify-center shadow-lg">ST</div>
      </div>
      <div className="backdrop-blur-md bg-white/80 shadow-xl rounded-lg p-6 max-w-3xl w-full">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold text-green-700">{t('appTitle')}</h1>
          <select value={i18n.language} onChange={e => i18n.changeLanguage(e.target.value)} className="border p-2 rounded">
            <option value="es">ES</option><option value="en">EN</option><option value="ru">RU</option>
          </select>
        </div>
        <div className="mb-4 flex flex-wrap gap-2">
          <input className="border p-2 rounded" type="text" placeholder={t('cropName')} value={nombreCultivo} onChange={e => setNombreCultivo(e.target.value)} />
          <input className="border p-2 rounded" type="date" value={fechaSiembra} onChange={e => setFechaSiembra(e.target.value)} />
          <input className="border p-2 w-24 rounded" type="number" min="1" value={frecuenciaRiego} onChange={e => setFrecuenciaRiego(e.target.value)} />
          <button onClick={agregarCultivo} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">{t('add')}</button>
        </div>
        <Calendar tileContent={({ date }) => {
          const riego = diasRiego.filter(d => isSameDay(d.fecha, date));
          return riego.length > 0 ? <div className="text-xs bg-blue-200 rounded p-1 mt-1">💧 {riego.map(r => r.nombre).join(", ")}</div> : null;
        }} />
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-2 text-green-700">{t('cropList')}</h2>
          <ul className="list-disc pl-6">
            {cultivos.map(c => <li key={c.id}>🌱 <strong>{c.nombre}</strong> - {format(c.fecha, "dd/MM/yyyy")} - Riego cada {c.frecuencia} días</li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
